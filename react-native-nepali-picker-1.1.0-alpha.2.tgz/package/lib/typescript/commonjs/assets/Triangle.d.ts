declare const Triangle: ({ width, height, color }: {
    width?: number | undefined;
    height?: number | undefined;
    color?: string | undefined;
}) => import("react/jsx-runtime").JSX.Element;
export default Triangle;
//# sourceMappingURL=Triangle.d.ts.map