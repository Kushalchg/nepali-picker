declare const PencilIcon: ({ height, width }: {
    height?: number | undefined;
    width?: number | undefined;
}) => import("react/jsx-runtime").JSX.Element;
export default PencilIcon;
//# sourceMappingURL=cIcon.d.ts.map