declare const ChevronIcon: ({ direction, size, color }: {
    direction?: string | undefined;
    size?: number | undefined;
    color?: string | undefined;
}) => import("react/jsx-runtime").JSX.Element;
declare const EditPencilIcon: ({ size, color }: {
    size?: number | undefined;
    color?: string | undefined;
}) => import("react/jsx-runtime").JSX.Element;
declare const Triangle: ({ width, height, color }: {
    width?: number | undefined;
    height?: number | undefined;
    color?: string | undefined;
}) => import("react/jsx-runtime").JSX.Element;
declare const ChevronDown: ({ size, color }: {
    size?: number | undefined;
    color?: string | undefined;
}) => import("react/jsx-runtime").JSX.Element;
export { ChevronIcon, ChevronDown, EditPencilIcon, Triangle };
//# sourceMappingURL=Icons.d.ts.map