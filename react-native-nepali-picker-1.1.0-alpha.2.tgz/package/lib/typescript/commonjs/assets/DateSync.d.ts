declare const DateSyncLogo: ({ size, color, day }: {
    size?: number | undefined;
    color?: string | undefined;
    day?: number | undefined;
}) => import("react/jsx-runtime").JSX.Element;
export default DateSyncLogo;
//# sourceMappingURL=DateSync.d.ts.map