import type { CalendarPickerProps } from './types';
declare const CalendarPicker: ({ visible, onClose, theme, onDateSelect, language, date, minDate, maxDate, brandColor, titleTextStyle, weekTextStyle, dayTextStyle, }: CalendarPickerProps) => import("react/jsx-runtime").JSX.Element;
export default CalendarPicker;
//# sourceMappingURL=CalendarPicker.d.ts.map