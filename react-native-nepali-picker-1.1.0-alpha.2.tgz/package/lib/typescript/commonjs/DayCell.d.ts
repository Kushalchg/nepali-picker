import React from 'react';
type DayCellProps = {
    day: number | null;
    isSelectedDay: boolean;
    onPress: (day: number) => void;
    dark: boolean;
    brandColor: string;
    language: 'np' | 'en';
    dayTextStyle?: any;
    disabled: boolean;
};
declare const DayCell: React.MemoExoticComponent<({ day, isSelectedDay, onPress, dark, brandColor, language, dayTextStyle, disabled, }: DayCellProps) => import("react/jsx-runtime").JSX.Element>;
export default DayCell;
//# sourceMappingURL=DayCell.d.ts.map