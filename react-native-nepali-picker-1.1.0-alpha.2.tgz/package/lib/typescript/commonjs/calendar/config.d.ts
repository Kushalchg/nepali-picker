declare const bs: number[][];
declare const leapYears: number[];
declare const daysInEnglish: string[];
declare const daysInNepali: string[];
declare const monthsInEnglish: string[];
declare const monthsInNepali: string[];
declare const getNepaliNumber: (engNum: number) => string;
export { bs, daysInNepali, daysInEnglish, monthsInNepali, monthsInEnglish, getNepaliNumber, leapYears, };
//# sourceMappingURL=config.d.ts.map