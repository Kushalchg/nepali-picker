import type { DateString } from '../types';
declare const formatDate: (date: Date) => string;
export declare const validateDate: (uDate: string) => true | string;
declare const FindDateDifference: (date1: number, date2: number) => number;
declare const AdToBs: (UserDate: DateString) => DateString;
declare const NepaliToday: () => DateString;
declare const BsToAd: (userDate: DateString) => DateString;
export { AdToBs, BsToAd, formatDate, FindDateDifference, NepaliToday };
//# sourceMappingURL=functions.d.ts.map