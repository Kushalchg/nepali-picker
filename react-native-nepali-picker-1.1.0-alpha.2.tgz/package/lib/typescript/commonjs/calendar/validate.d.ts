export declare const validateCalendarDates: (date: string, minDate: string, maxDate: string) => true | string;
//# sourceMappingURL=validate.d.ts.map