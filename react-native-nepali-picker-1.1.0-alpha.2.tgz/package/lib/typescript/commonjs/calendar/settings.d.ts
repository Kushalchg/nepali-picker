export declare const NEPALI_MIN_YEAR = 2000;
export declare const NEPALI_MAX_YEAR = 2099;
declare const calcFirstDay: (currentYear: number, currentMonth: number) => number;
declare const isToday: (date: string, index: number, currentYear: number, currentMonth: number, firstDayOfMonth: number) => boolean;
export { calcFirstDay, isToday };
//# sourceMappingURL=settings.d.ts.map